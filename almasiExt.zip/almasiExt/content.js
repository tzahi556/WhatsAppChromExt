﻿


$(document).ready(function () {
  

    alert();
    $(document).click(function () {
       
    
     
    });

    

});
