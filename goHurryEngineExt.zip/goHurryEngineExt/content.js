﻿

var bankUserName = "";
var bankPassword = "";

$(document).ready(function () {
  
 
    chrome.storage.sync.get(['gohUserName'], function (result) {
        $("#ctl00_PlaceHolderLogin_ctl00_tbUserName").val(result.gohUserName);
    });

    chrome.storage.sync.get(['gohPassword'], function (result) {
        $("#ctl00_PlaceHolderLogin_ctl00_tbPassword").val(result.gohPassword);
        setTimeout(function () {
            $("#ctl00_PlaceHolderLogin_ctl00_Enter")[0].click();
        }, 1000)
    });

   
    $(document).click(function () {
       
        var eventId = $(event.target).attr('id');
        if (eventId == "dvOpenBankLink" || eventId == "dvOpenBankImg") {

            bankUserName = $("#txtBankUserName").val();
            chrome.storage.sync.set({'gohUserName': bankUserName }, function () {
            });


            bankPassword = $("#txtBankPassword").val();
            chrome.storage.sync.set({ 'gohPassword': bankPassword }, function () {
            });
        }

     
    });

    

});
